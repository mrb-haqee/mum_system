<?php
include_once '../../../../../library/konfigurasi.php';
include_once "{$constant('BASE_URL_PHP')}/library/konfigurasidatabase.php";
include_once "{$constant('BASE_URL_PHP')}/library/fungsienkripsidekripsi.php";
include_once "{$constant('BASE_URL_PHP')}/library/konfigurasikuncirahasia.php";
include_once "{$constant('BASE_URL_PHP')}/library/konfigurasistock.php";
include_once "{$constant('BASE_URL_PHP')}/library/fungsialert.php";
include_once "{$constant('BASE_URL_PHP')}/library/fungsiutilitas.php";
include_once "{$constant('BASE_URL_PHP')}/library/fungsirupiah.php";
include_once "{$constant('BASE_URL_PHP')}/library/fungsistatement.php";
include_once "{$constant('BASE_URL_PHP')}/library/fungsitanggal.php";


include_once "{$constant('BASE_URL_PHP')}{$constant('VENDOR_SATU_SEHAT_DIR')}/load.php";

session_start();

$idUser    = '';
$tokenCSRF = '';

extract($_SESSION);

//DESKRIPSI ID USER
$idUserAsli = dekripsi($idUser, secretKey());

//MENGECEK APAKAH ID USER YANG LOGIN ADA PADA DATABASE
$sqlCekUser = $db->prepare('SELECT idUser, idPegawai FROM user WHERE idUser=?');
$sqlCekUser->execute([$idUserAsli]);
$dataCekUser = $sqlCekUser->fetch();


//MENGECEK APAKAH USER INI BERHAK MENGAKSES MENU INI
$sqlCekMenu = $db->prepare(
    'SELECT 
		* 
	from 
		user_detail 
		INNER JOIN menu_sub ON menu_sub.idSubMenu = user_detail.idSubMenu
	WHERE
		user_detail.idUser = ?
		AND menu_sub.namaFolder = ?
	'
);
$sqlCekMenu->execute([
    $idUserAsli,
    getMenuDirectory(BASE_URL_PHP, __DIR__)
]);
$dataCekMenu = $sqlCekMenu->fetch();

//KICK SAAT ID USER TIDAK ADA PADA DATABASE
if (!$dataCekUser || !$dataCekMenu || !validateIP($_SESSION['IP_ADDR'])) {
    alertSessionExpForm();
} else {

    $dataPegawai = selectStatement(
        'SELECT pegawai.* FROM pegawai WHERE idPegawai = ?',
        [$dataCekUser['idPegawai']],
        'fetch'
    );

    extract($_POST, EXTR_SKIP);

    $dataUpdate = statementWrapper(
        DML_SELECT,
        'SELECT 
            obat.*,
            obat_satusehat.* 
        FROM 
            obat
            LEFT JOIN obat_satusehat ON obat.kodeObat = obat_satusehat.kodeObat 
        WHERE 
            obat.kodeObat = ?
        ',
        [$kodeObat]
    );

    if ($dataUpdate) {
        $flag = 'update';
    } else {
        $flag = 'tambah';
    }


?>
    <div class="card card-custom">
        <!-- CARD HEADER -->
        <div class="card-header">
            <!-- CARD TITLE -->
            <div class="card-title">
                <h3 class="card-label">
                    <span class="card-label font-weight-bolder text-dark d-block">
                        <i class="fa fa-info-circle text-dark"></i> Inventory Obat
                    </span>
                    <span class="mt-3 font-weight-bold font-size-sm">
                        <?= PAGE_TITLE; ?>
                    </span>
                </h3>
            </div>
            <!-- END CARD TITLE -->
        </div>
        <!-- END CARD HEADER -->

        <!-- CARD BODY -->
        <div class="card-body">
            <form id="formObat">
                <input type="hidden" name="tokenCSRFForm" value="<?= $tokenCSRF ?>">
                <input type="hidden" name="kodeObat" value="<?= $kodeObat ?>">
                <input type="hidden" name="flag" value="<?= $flag ?>">

                <div class="form-group">
                    <label><i class="fa fa-list"></i> Nama Obat</label>
                    <input type="text" class="form-control" id="nama" name="nama" placeholder="Nama Obat" value="<?= $dataUpdate['nama'] ?? '' ?>">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-tag"></i> Kode KFA</label>
                    <input type="text" class="form-control" id="kodeKFA" name="kodeKFA" placeholder="kode KFA" value="<?= $dataUpdate['kodeKFA'] ?? '' ?>">
                </div>

                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label><i class="fa fa-list"></i> Golongan</label>
                        <input type="text" class="form-control" id="golongan" name="golongan" placeholder="Golongan" value="<?= $dataUpdate['golongan'] ?? '' ?>">
                    </div>
                    <div class="form-group col-sm-6">
                        <label><i class="fas fa-thumbtack"></i> Satuan</label>
                        <select id="satuanPenjualan" name="satuanPenjualan" class="form-control select2" style="width: 100%;">
                            <?php
                            $opsiSatuan = getListSatuanStock();
                            foreach ($opsiSatuan as $row) {
                                $selected = selected($row['satuan'], $dataUpdate['satuanPenjualan'] ?? '');
                            ?>
                                <option value="<?= $row['satuan'] ?>" <?= $selected ?>><?= $row['satuan'] ?></option>
                            <?php
                            }
                            ?>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-sm-6">
                        <label><i class="fas fa-pills"></i> Jenis Racikan <sup>( Wajib Satu Sehat )</sup></label>
                        <select class="form-control selectpicker" id="jenisRacikan" name="jenisRacikan">
                            <option value="">Pilih Jenis</option>
                            <?php
                            $forms = \SatuSehat\FHIR\Interoperabilitas\MedicationType::optionsFromStatic();
                            foreach ($forms as $form) {
                                $invoke = call_user_func(\SatuSehat\FHIR\Interoperabilitas\MedicationType::class . '::' . $form['name']);
                                $selected = selected($form['name'], $dataUpdate['jenisRacikan'] ?? '');
                            ?>
                                <option value="<?= $form['name'] ?>" <?= $selected; ?>><?= $invoke->__keterangan; ?></option>
                            <?php
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group col-sm-6">
                        <label><i class="fas fa-pills"></i> Bentuk Obat <sup>( Wajib Satu Sehat )</sup></label>
                        <select class="form-control select2" id="jenisObat" name="jenisObat" style="width: 100%;">
                            <option value="">Pilih Bentuk</option>
                            <?php
                            $forms = \SatuSehat\DataType\Other\MedicationForm::optionsFromStatic();
                            foreach ($forms as $form) {
                                $invoke = call_user_func(\SatuSehat\DataType\Other\MedicationForm::class . '::' . $form['name'], 1, '');
                                $selected = selected($form['name'], $dataUpdate['jenisObat'] ?? '');
                            ?>
                                <option value="<?= $form['name'] ?>" <?= $selected; ?>><?= $invoke->display; ?></option>
                            <?php
                            }
                            ?>
                        </select>
                    </div>
                </div>
                <div class="container-fluid p-4 border rounded mb-5">
                    <div class="form-row">
                        <div class="col-md-3">
                            <input type="text" style="font-weight:bolder" class="form-control" disabled value="NUMERATOR">
                        </div>
                        <div class="col-md-6">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        QTY
                                    </span>
                                </div>
                                <input type="text" name="qtyNumerator" id="qtyNumerator" placeholder="Qty" value="<?= $dataUpdate['qtyNumerator'] ? ubahToRupiahDesimal($dataUpdate['qtyNumerator']) : '' ?>" class="form-control" onkeyup="" data-format-rupiah="active">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        UNIT
                                    </span>
                                </div>
                                <select name="unitNumerator" id="unitNumerator" class="form-control selectpicker" onchange="">
                                    <?php
                                    $forms = \SatuSehat\DataType\Other\Measurement::optionsFromStatic();
                                    foreach ($forms as $form) {
                                        $invoke = call_user_func(\SatuSehat\DataType\Other\Measurement::class . '::' . $form['name'], 1, '');
                                        if (in_array($invoke->code, ['g', 'mg', 'L', 'mL'])) {
                                            $selected = selected($form['name'], $dataUpdate['unitNumerator'] ?? '');
                                    ?>
                                            <option value="<?= $form['name'] ?>" <?= $selected; ?> data-code="<?= $invoke->code ?>"><?= $invoke->code ?> (<?= $invoke->__display; ?>)</option>
                                    <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <br>
                    <div class="form-row">
                        <div class="col-md-3">
                            <input type="text" style="font-weight:bolder" class="form-control" disabled value="DENOMINATOR">
                        </div>
                        <div class="col-md-6">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        QTY
                                    </span>
                                </div>
                                <input type="text" name="qtyDenominator" id="qtyDenominator" value="<?= $dataUpdate['qtyDenominator'] ? ubahToRupiahDesimal($dataUpdate['qtyDenominator']) : '' ?>" placeholder="Qty" class="form-control" onkeyup="" data-format-rupiah="active">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        UNIT
                                    </span>
                                </div>
                                <select name="unitDenominator" id="unitDenominator" class="form-control selectpicker" onchange="">
                                    <?php
                                    $forms = \SatuSehat\DataType\Other\Measurement::optionsFromStatic();
                                    foreach ($forms as $form) {
                                        $invoke = call_user_func(\SatuSehat\DataType\Other\Measurement::class . '::' . $form['name'], 1, '');
                                        if (in_array($invoke->code, ['g', 'mg', 'L', 'mL', '[IU]'])) {
                                            $selected = selected($form['name'], $dataUpdate['unitDenominator'] ?? '');
                                    ?>
                                            <option value="<?= $form['name'] ?>" <?= $selected; ?> data-code="<?= $invoke->code ?>"><?= $invoke->code ?> (<?= $invoke->__display; ?>)</option>
                                        <?php
                                        }
                                    }

                                    $forms = \SatuSehat\DataType\Other\DrugForm::optionsFromStatic();
                                    foreach ($forms as $form) {

                                        $invoke = call_user_func(\SatuSehat\DataType\Other\DrugForm::class . '::' . $form['name'], 1, '');
                                        $selected = selected($form['name'], $dataUpdate['unitDenominator'] ?? '');
                                        ?>

                                        <option value="<?= $form['name'] ?>" <?= $selected; ?> data-code="<?= $invoke->code ?>"><?= $invoke->__display ?></option>
                                    <?php

                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-money-bill"></i> Harga Beli</label>
                    <input type="text" class="form-control" id="hargaBeli" name="hargaBeli" placeholder="Harga Beli" data-format-rupiah="active" value="<?= ubahToRp($dataUpdate['hargaBeli'] ?? 0) ?>">
                </div>

                <div class="form-group">
                    <?php
                    if ($flag === 'update') {
                    ?>
                        <button type="button" class="btn btn-info" onclick="prosesObat()">
                            <i class="fas fa-save pr-3"></i> <strong>SIMPAN</strong>
                        </button>
                    <?php
                    } else if ($flag === 'tambah') {
                    ?>
                        <button type="button" class="btn btn-primary" onclick="prosesObat()">
                            <i class="fas fa-save pr-3"></i> <strong>SIMPAN</strong>
                        </button>
                    <?php
                    }
                    ?>
                </div>

            </form>
        </div>
    </div>
<?php
}
?>