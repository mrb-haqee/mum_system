function seksiFormFinalisasi() {
    let kodeObat = $("#kodeObat").val();
    $.ajax({
        url: "seksi_finalisasi/form-finalisasi.php",
        type: "post",
        data: {
            kodeObat: kodeObat,
        },
        beforeSend: function () {
            $(".loader-custom").show();
        },
        success: function (data, status) {
            $("#formDetailInventoryObat").html(data);
            $(".loader-custom").hide();
        },
    });
}

function prosesFinalisasi() {
    const kodeObat = $("input[name=kodeObat]").val();
    const tokenCSRFForm = $("input[name=tokenCSRFForm]").val();

    $.ajax({
        url: "seksi_finalisasi/proses-finalisasi.php",
        type: "post",
        data: {
            flag: "finalisasi",
            kodeObat,
            tokenCSRFForm,
        },
        dataType: "json",

        beforeSend: function () {},

        success: function (data) {
            const { status, pesan } = data;

            notifikasi(status, pesan);

            if (status) {
                setTimeout(() => {
                    window.location.href = "../";
                }, 500);
            }
        },
    });
}
