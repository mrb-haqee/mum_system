function seksiFormInformasi() {
    let kodeObat = $("#kodeObat").val();
    $.ajax({
        url: "seksi_informasi/form-informasi.php",
        type: "post",
        data: {
            kodeObat: kodeObat,
        },
        beforeSend: function () {
            $(".loader-custom").show();
        },
        success: function (data, status) {
            //console.log(data);
            $("#formDetailInventoryObat").html(data);

            $(".loader-custom").hide();
            $("select.selectpicker").selectpicker();
            $("select.select2").select2();
        },
    });
}

function prosesObat() {
    const formObat = document.getElementById("formObat");
    const dataForm = new FormData(formObat);

    const validasi = formValidation(dataForm);

    if (validasi) {
        $.ajax({
            url: "seksi_informasi/proses-obat.php",
            type: "post",
            enctype: "multipart/form-data",
            processData: false,
            contentType: false,
            data: dataForm,
            dataType: "json",

            beforeSend: function () {},

            success: function (data) {
                const { status, pesan } = data;
                notifikasi(status, pesan);

                seksiFormInformasi();
            },
        });
    }
}
