function seksiFormBiaya(idObatHarga = "") {
    let kodeObat = $("#kodeObat").val();
    $.ajax({
        url: "seksi_biaya/form-biaya.php",
        type: "post",
        data: {
            kodeObat: kodeObat,
            idObatHarga,
        },
        beforeSend: function () {
            $(".loader-custom").show();
        },
        success: function (data, status) {
            //console.log(data);
            $("#formDetailInventoryObat").html(data);
            $(".loader-custom").hide();
            $("select.selectpicker").selectpicker();
        },
    });
}

function prosesBiaya(index) {
    let formBiaya = document.getElementById("formBiaya_" + index);
    let dataForm = new FormData(formBiaya);

    dataForm.append("__FORM_ID__", "formBiaya_" + index);

    const validasi = formValidation(dataForm);

    if (validasi) {
        $.ajax({
            url: "seksi_biaya/proses-biaya.php",
            type: "post",
            enctype: "multipart/form-data",
            processData: false,
            contentType: false,
            data: dataForm,
            dataType: "json",

            beforeSend: function () {},

            success: function (data) {
                const { status, pesan } = data;
                notifikasi(status, pesan);

                seksiFormBiaya();
            },
        });
    }
}

function konfirmasiBatalBiaya(id, token) {
    Swal.fire({
        title: "Apakah anda yakin?",
        text: "Setelah dibatalkan, proses tidak dapat diulangi!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Ya!",
        cancelButtonText: "Tidak!",
    }).then(function (result) {
        if (result.value) {
            $.ajax({
                url: "seksi_biaya/proses-biaya.php",
                type: "post",
                data: {
                    tokenCSRFForm: token,
                    idObatHarga: id,
                    flag: "delete",
                },

                dataType: "json",

                success: function (data) {
                    const { status, pesan } = data;
                    notifikasi(status, pesan);

                    seksiFormBiaya();
                },
            });
        } else if (result.dismiss === "cancel") {
            Swal.fire("Dibatalkan", "Proses dibatalkan!", "error");
        }
    });
}
