<?php
include_once '../../../library/konfigurasi.php';
include_once "{$constant('BASE_URL_PHP')}/library/konfigurasidatabase.php";
include_once "{$constant('BASE_URL_PHP')}/library/fungsienkripsidekripsi.php";
include_once "{$constant('BASE_URL_PHP')}/library/konfigurasikuncirahasia.php";
include_once "{$constant('BASE_URL_PHP')}/library/konfigurasijenisharga.php";
include_once "{$constant('BASE_URL_PHP')}/library/fungsialert.php";
include_once "{$constant('BASE_URL_PHP')}/library/fungsiutilitas.php";
include_once "{$constant('BASE_URL_PHP')}/library/fungsirupiah.php";
include_once "{$constant('BASE_URL_PHP')}/library/fungsistatement.php";
include_once "{$constant('BASE_URL_PHP')}/library/fungsitanggal.php";

session_start();

$idUser    = '';
$tokenCSRF = '';

extract($_SESSION);

//DESKRIPSI ID USER
$idUserAsli = dekripsi($idUser, secretKey());

//MENGECEK APAKAH ID USER YANG LOGIN ADA PADA DATABASE
$sqlCekUser = $db->prepare('SELECT idUser, idPegawai FROM user WHERE idUser=?');
$sqlCekUser->execute([$idUserAsli]);
$dataCekUser = $sqlCekUser->fetch();

//MENGECEK APAKAH USER INI BERHAK MENGAKSES MENU INI
$sqlCekMenu = $db->prepare(
    'SELECT 
		* 
	from 
		user_detail 
		INNER JOIN menu_sub ON menu_sub.idSubMenu = user_detail.idSubMenu
	WHERE
		user_detail.idUser = ?
		AND menu_sub.namaFolder = ?
	'
);
$sqlCekMenu->execute([
    $idUserAsli,
    getMenuDirectory(BASE_URL_PHP, __DIR__)
]);
$dataCekMenu = $sqlCekMenu->fetch();

//KICK SAAT ID USER TIDAK ADA PADA DATABASE
if (!$dataCekUser || !$dataCekMenu || !validateIP($_SESSION['IP_ADDR'])) {
    alertSessionExpForm();
} else {

    $dataPegawai = selectStatement(
        'SELECT pegawai.* FROM pegawai WHERE idPegawai = ?',
        [$dataCekUser['idPegawai']],
        'fetch'
    );

    extract($_POST, EXTR_SKIP);


    $dataObat = statementWrapper(
        DML_SELECT,
        "SELECT
            *
        FROM
            obat
        WHERE
            idObat = ?   
        ",
        [$idObat]
    );

?>

    <div class="row" id="detail_<?= $idObat ?>">
        <?php

        $daftarAdmisi = statementWrapper(
            DML_SELECT_ALL,
            'SELECT * FROM admisi WHERE statusAdmisi = ?',
            ['Aktif']
        );

        foreach ($daftarAdmisi as $index => $admisi) {

            $daftarObatHarga = statementWrapper(
                DML_SELECT_ALL,
                'SELECT * FROM obat_harga WHERE kodeObat = ? AND idAdmisi = ? AND statusObatHarga = ? ORDER BY jenisHarga',
                [$dataObat['kodeObat'], $admisi['idAdmisi'], 'Aktif']
            );

            $cekSemuaJenisHarga = array_column($daftarObatHarga, 'jenisHarga');
        ?>
            <div class="form-group col-md-6">
                <table class="table table-bordered">
                    <tbody>
                        <tr>
                            <td colspan="2"> <i class="fas fa-layer-group pr-5" style="font-size: 1rem;"></i><strong class="text-uppercase"> <?= $admisi['namaAdmisi']; ?></strong></td>
                        </tr>
                        <?php
                        foreach ($daftarObatHarga as $obatBiaya) {
                        ?>
                            <tr>
                                <td class="align-middle">
                                    <strong>
                                        <?= $obatBiaya['jenisHarga'] ?>
                                    </strong>
                                </td>
                                <td class="align-middle">Rp <?= ubahToRp($obatBiaya['nominal']) ?></td>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        <?php
        }
        ?>
    </div>
<?php
}
?>