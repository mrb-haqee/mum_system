<?php
include_once '../../../../../library/konfigurasi.php';
include_once "{$constant('BASE_URL_PHP')}/library/konfigurasidatabase.php";
include_once "{$constant('BASE_URL_PHP')}/library/fungsienkripsidekripsi.php";
include_once "{$constant('BASE_URL_PHP')}/library/konfigurasikuncirahasia.php";
include_once "{$constant('BASE_URL_PHP')}/library/fungsialert.php";
include_once "{$constant('BASE_URL_PHP')}/library/fungsiutilitas.php";
include_once "{$constant('BASE_URL_PHP')}/library/fungsirupiah.php";
include_once "{$constant('BASE_URL_PHP')}/library/fungsistatement.php";
include_once "{$constant('BASE_URL_PHP')}/library/fungsitanggal.php";
include_once "{$constant('BASE_URL_PHP')}/library/fungsinomor.php";

session_start();

$idUser    = '';
$tokenCSRF = '';

extract($_SESSION);

//DESKRIPSI ID USER
$idUserAsli = dekripsi($idUser, secretKey());

//MENGECEK APAKAH ID USER YANG LOGIN ADA PADA DATABASE
$sqlCekUser = $db->prepare('SELECT idUser, idPegawai FROM user WHERE idUser=?');
$sqlCekUser->execute([$idUserAsli]);
$dataCekUser = $sqlCekUser->fetch();

//MENGECEK APAKAH USER INI BERHAK MENGAKSES MENU INI
$sqlCekMenu = $db->prepare(
    'SELECT 
		* 
	from 
		user_detail 
		INNER JOIN menu_sub ON menu_sub.idSubMenu = user_detail.idSubMenu
	WHERE
		user_detail.idUser = ?
		AND menu_sub.namaFolder = ?
	'
);
$sqlCekMenu->execute([
    $idUserAsli,
    getMenuDirectory(BASE_URL_PHP, __DIR__)
]);
$dataCekMenu = $sqlCekMenu->fetch();

$tokenValid = hash_equals($tokenCSRF, $_POST['tokenCSRFForm'] ?? '');
//KICK SAAT ID USER TIDAK ADA PADA DATABASE
if (!$dataCekUser || !$dataCekMenu || !validateIP($_SESSION['IP_ADDR']) || !$tokenValid) {
    $data = array('status' => false, 'pesan' => 'Proses Authentikasi Gagal, Data Tidak Valid');
} else {

    $dataPegawai = selectStatement(
        'SELECT pegawai.* FROM pegawai WHERE idPegawai = ?',
        [$dataCekUser['idPegawai']],
        'fetch'
    );

    sanitizeInput($_POST);
    extract($_POST, EXTR_SKIP);

    try {

        if ($flag === 'delete') {
            $status = statementWrapper(
                DML_DELETE,
                'UPDATE obat_harga SET statusObatHarga = ? WHERE idObatHarga = ?',
                ['Non Aktif', $idObatHarga]
            );

            if ($status) {
                $pesan = 'Proses Non Aktif Obat Harga Berhasil';
            } else {
                $pesan = 'Proses Non Aktif Obat Harga Gagal';
            }
        } else if ($flag === 'update') {
            if ($copyType === 'Per Admisi') {
                $status = statementWrapper(
                    DML_UPDATE,
                    'UPDATE
                        obat_harga 
                    SET 
                        idAdmisi = ?, 
                        jenisHarga = ?, 
                        nominal = ?,
                        idUser = ?
                    WHERE
                        idObatHarga = ?
                    ',
                    [
                        $idAdmisi,
                        $jenisHarga,
                        ubahToInt($nominal),
                        $idUserAsli,
                        $idObatHarga
                    ]
                );
            } else if ($copyType === 'Semua Admisi') {
                $status = statementWrapper(
                    DML_UPDATE,
                    'UPDATE
                        obat_harga 
                    SET 
                        nominal = ?,
                        idUser = ?
                    WHERE
                        jenisHarga = ?
                        AND kodeObat = ?
                        AND statusObatHarga = ?
                    ',
                    [
                        ubahToInt($nominal),
                        $idUserAsli,
                        $jenisHarga,
                        $kodeObat,
                        'Aktif'
                    ]
                );
            }

            if ($status) {
                $pesan = 'Proses Update Obat Harga Berhasil';
            } else {
                $pesan = 'Proses Update Obat Harga Gagal';
            }
        } else if ($flag === 'tambah') {
            if ($copyType === 'Per Admisi') {
                $status = statementWrapper(
                    DML_INSERT,
                    "INSERT INTO 
                        obat_harga 
                    SET 
                        kodeObat = ?, 
                        idAdmisi = ?, 
                        jenisHarga = ?, 
                        nominal = ?, 
                        statusObatHarga = ?,
                        idUser = ?
                    ON DUPLICATE KEY UPDATE
                        nominal = ?,
                        statusObatHarga = 'Aktif'
                    ",
                    [
                        $kodeObat,
                        $idAdmisi,
                        $jenisHarga,
                        ubahToInt($nominal),
                        'Aktif',
                        $idUserAsli,
                        ubahToInt($nominal),
                    ]
                );
            } else if ($copyType === 'Semua Admisi') {
                $status = statementWrapper(
                    DML_INSERT,
                    "INSERT INTO 
                        obat_harga 
                        (
                            kodeObat,
                            idAdmisi,
                            jenisHarga,
                            nominal,
                            statusObatHarga,
                            idUser
                        )
                    SELECT
                        ? as kodeObat,
                        idAdmisi, 
                        ? as jenisHarga, 
                        ? as nominal, 
                        ? as statusObatHarga,
                        ? as idUser
                    FROM
                        admisi
                    WHERE
                        statusAdmisi = 'Aktif'
                    ON DUPLICATE KEY UPDATE
                        nominal = ?,
                        statusObatHarga = 'Aktif'
                    ",
                    [
                        $kodeObat,
                        $jenisHarga,
                        ubahToInt($nominal),
                        'Aktif',
                        $idUserAsli,
                        ubahToInt($nominal),
                    ]
                );
            }

            if ($status) {
                $pesan = 'Proses Tambah Obat Harga Berhasil';
            } else {
                $pesan = 'Proses Tambah Obat Harga Gagal';
            }
        }
    } catch (PDOException $e) {
        $status = false;
        $pesan = 'Terdapat Kesalahan Dalam Proses Input ke Database';
    } finally {
        $data = compact('status', 'pesan');
    }
}

echo json_encode($data);
