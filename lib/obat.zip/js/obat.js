document.addEventListener("readystatechange", function (event) {
    if (document.readyState === "complete") {
        dataDaftarObat();
    }
});

function dataCariDaftarObat() {
    const search = $("#search").val();

    if (search) {
        $.ajax({
            url: "data-daftar-obat.php",
            type: "post",
            data: {
                search: search,
                flag: "cari",
            },
            beforeSend: function () {
                $(".overlay").show();
            },
            success: function (data, status) {
                $("#dataDaftarObat").html(data);
                $(".overlay").hide();
            },
        });
    }
}

function dataDaftarObat() {
    $.ajax({
        url: "data-daftar-obat.php",
        type: "post",
        data: {
            flag: "daftar",
        },
        beforeSend: function () {
            $(".overlay").show();
        },
        success: function (data, status) {
            $("#dataDaftarObat").html(data);
            $(".overlay").hide();
        },
    });
}

function konfirmasiBatalObat(kode, token) {
    Swal.fire({
        title: "Apakah anda yakin?",
        text: "Setelah dibatalkan, proses tidak dapat diulangi!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Ya!",
        cancelButtonText: "Tidak!",
    }).then(function (result) {
        if (result.value) {
            $.ajax({
                url: "proses-obat.php",
                type: "post",
                data: {
                    tokenCSRFForm: token,
                    kodeObat: kode,
                    flag: "delete",
                },
                dataType: "json",
                success: function (data) {
                    const { status, pesan } = data;
                    notifikasi(status, pesan);

                    dataDaftarObat();
                },
            });
        } else if (result.dismiss === "cancel") {
            Swal.fire("Dibatalkan", "Proses dibatalkan!", "error");
        }
    });
}

function notifikasi(status, pesan) {
    if (status === true) {
        toastr.success(pesan);
    } else {
        toastr.error(pesan);
    }
}
